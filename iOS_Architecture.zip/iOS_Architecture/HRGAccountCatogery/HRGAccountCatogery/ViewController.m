//
//  ViewController.m
//  HRGAccountCatogery
//
//  Created by lyy on 2018/11/20.
//  Copyright © 2018 HRG. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
