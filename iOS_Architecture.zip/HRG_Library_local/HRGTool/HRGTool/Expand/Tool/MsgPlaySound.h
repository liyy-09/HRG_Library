//
//  MsgPlaySound.h
//  SHAREMEDICINE_EMPLOYEE_iOS
//
//  Created by lyy on 2018/11/19.
//  Copyright © 2018 HRG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MsgPlaySound : NSObject

- (void)playVibrate;
- (void)playMusic;
- (void)dispose;

@end
